export interface AuditFormData {
  websiteUrl: string;
  businessName: string;
  industry: string;
  competitors: string[];
  socialMedia?: {
    facebook?: string;
    instagram?: string;
    linkedin?: string;
    twitter?: string;
    tiktok?: string;
    youtube?: string;
  };
}

export interface SEOMetrics {
  title: string;
  metaDescription: string;
  hasH1: boolean;
  imageAltTags: number;
  totalImages: number;
  internalLinks: number;
  externalLinks: number;
  pageLoadTime: number;
  mobileResponsive: boolean;
  httpsEnabled: boolean;
  structuredData: boolean;
}

export interface PerformanceMetrics {
  loadTime: number;
  firstContentfulPaint: number;
  largestContentfulPaint: number;
  cumulativeLayoutShift: number;
  timeToInteractive: number;
  totalBlockingTime: number;
  speedIndex: number;
}

export interface AccessibilityMetrics {
  score: number;
  issues: {
    critical: number;
    serious: number;
    moderate: number;
    minor: number;
  };
  colorContrast: boolean;
  keyboardNavigation: boolean;
  ariaLabels: boolean;
  altText: boolean;
}

export interface GEOMetrics {
  aiReadability: number;
  structuredDataPresent: boolean;
  schemaMarkup: string[];
  entityOptimisation: number;
  faqStructure: boolean;
  contentDepth: number;
  topicalAuthority: number;
}

export interface CompetitorData {
  name: string;
  url: string;
  monthlyVisits: number;
  bounceRate: number;
  avgVisitDuration: number;
  pagesPerVisit: number;
  topCountries: string[];
  trafficSources: {
    direct: number;
    search: number;
    social: number;
    referral: number;
  };
}

export interface AuditReport {
  websiteUrl: string;
  businessName: string;
  industry: string;
  generatedAt: string;
  seo: SEOMetrics;
  performance: PerformanceMetrics;
  accessibility: AccessibilityMetrics;
  geo: GEOMetrics;
  socialMedia: SocialMediaAudit;
  competitors: CompetitorData[];
  recommendations: Recommendation[];
  overallScore: number;
}

export interface SocialMediaProfile {
  platform: 'Facebook' | 'Instagram' | 'LinkedIn' | 'Twitter' | 'TikTok' | 'YouTube';
  url: string;
  found: boolean;
  profileComplete: boolean;
  postingFrequency: 'Daily' | 'Weekly' | 'Monthly' | 'Rarely' | 'Never';
  lastPostDate?: string;
  followerCount?: number;
  engagementRate?: number;
  issues: string[];
}

export interface SocialMediaAudit {
  profilesFound: number;
  totalPlatforms: number;
  overallScore: number;
  profiles: SocialMediaProfile[];
  recommendations: string[];
}

export interface Recommendation {
  category: 'SEO' | 'Performance' | 'Accessibility' | 'GEO' | 'Voice' | 'Google Business' | 'Social Media';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  title: string;
  description: string;
  impact: string;
  implementation: string;
}
