import type {
  AuditReport,
  SEOMetrics,
  PerformanceMetrics,
  AccessibilityMetrics,
  GEOMetrics,
  CompetitorData,
  Recommendation,
  AuditFormData,
  SocialMediaAudit,
  SocialMediaProfile
} from './types';

/**
 * Simulates fetching website data and performing analysis
 * In a real implementation, this would call actual APIs
 */
export async function analyzeWebsite(formData: AuditFormData): Promise<AuditReport> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 2000));

  const url = new URL(formData.websiteUrl);
  
  // Generate mock data based on the URL
  const seo = generateSEOMetrics(url.hostname);
  const performance = generatePerformanceMetrics();
  const accessibility = generateAccessibilityMetrics();
  const geo = generateGEOMetrics();
  const socialMedia = generateSocialMediaAudit(url.hostname, formData.socialMedia);
  const competitors = await generateCompetitorData(formData.competitors, formData.websiteUrl, formData.businessName);
  const recommendations = generateRecommendations(seo, performance, accessibility, geo, socialMedia);
  const overallScore = calculateOverallScore(seo, performance, accessibility, geo);

  return {
    websiteUrl: formData.websiteUrl,
    businessName: formData.businessName,
    industry: formData.industry,
    generatedAt: new Date().toISOString(),
    seo,
    performance,
    accessibility,
    geo,
    socialMedia,
    competitors,
    recommendations,
    overallScore
  };
}

function generateSEOMetrics(hostname: string): SEOMetrics {
  return {
    title: `${hostname} - Home`,
    metaDescription: `Welcome to ${hostname}`,
    hasH1: Math.random() > 0.3,
    imageAltTags: Math.floor(Math.random() * 20),
    totalImages: Math.floor(Math.random() * 30) + 10,
    internalLinks: Math.floor(Math.random() * 50) + 10,
    externalLinks: Math.floor(Math.random() * 20),
    pageLoadTime: Math.random() * 3 + 1,
    mobileResponsive: Math.random() > 0.2,
    httpsEnabled: Math.random() > 0.1,
    structuredData: Math.random() > 0.5
  };
}

function generatePerformanceMetrics(): PerformanceMetrics {
  return {
    loadTime: Math.random() * 4 + 1,
    firstContentfulPaint: Math.random() * 2 + 0.5,
    largestContentfulPaint: Math.random() * 3 + 1,
    cumulativeLayoutShift: Math.random() * 0.3,
    timeToInteractive: Math.random() * 4 + 2,
    totalBlockingTime: Math.random() * 500,
    speedIndex: Math.random() * 4 + 2
  };
}

function generateAccessibilityMetrics(): AccessibilityMetrics {
  const score = Math.floor(Math.random() * 40) + 60;
  return {
    score,
    issues: {
      critical: Math.floor(Math.random() * 5),
      serious: Math.floor(Math.random() * 10),
      moderate: Math.floor(Math.random() * 15),
      minor: Math.floor(Math.random() * 20)
    },
    colorContrast: Math.random() > 0.3,
    keyboardNavigation: Math.random() > 0.4,
    ariaLabels: Math.random() > 0.5,
    altText: Math.random() > 0.3
  };
}

function generateGEOMetrics(): GEOMetrics {
  return {
    aiReadability: Math.floor(Math.random() * 40) + 50,
    structuredDataPresent: Math.random() > 0.5,
    schemaMarkup: ['Organization', 'LocalBusiness'].filter(() => Math.random() > 0.5),
    entityOptimisation: Math.floor(Math.random() * 40) + 40,
    faqStructure: Math.random() > 0.6,
    contentDepth: Math.floor(Math.random() * 40) + 50,
    topicalAuthority: Math.floor(Math.random() * 40) + 40
  };
}

async function generateCompetitorData(
  competitors: string[], 
  mainWebsiteUrl: string, 
  mainBusinessName: string
): Promise<CompetitorData[]> {
  // Include the main website first, then competitors
  const allWebsites = [mainWebsiteUrl, ...competitors];
  
  return allWebsites.map((url, index) => {
    const websiteUrl = new URL(url);
    const isMainSite = index === 0;
    
    return {
      name: isMainSite ? mainBusinessName : websiteUrl.hostname.replace('www.', ''),
      url,
      monthlyVisits: Math.floor(Math.random() * 500000) + 50000,
      bounceRate: Math.floor(Math.random() * 40) + 30,
      avgVisitDuration: Math.floor(Math.random() * 300) + 60,
      pagesPerVisit: Math.random() * 4 + 1,
      topCountries: ['United Kingdom', 'United States', 'Germany'],
      trafficSources: {
        direct: Math.floor(Math.random() * 40) + 10,
        search: Math.floor(Math.random() * 50) + 20,
        social: Math.floor(Math.random() * 20) + 5,
        referral: Math.floor(Math.random() * 20) + 5
      }
    };
  });
}

function generateSocialMediaAudit(
  hostname: string, 
  providedUrls?: {
    facebook?: string;
    instagram?: string;
    linkedin?: string;
    twitter?: string;
    tiktok?: string;
    youtube?: string;
  }
): SocialMediaAudit {
  const platforms: Array<'Facebook' | 'Instagram' | 'LinkedIn' | 'Twitter' | 'TikTok' | 'YouTube'> = 
    ['Facebook', 'Instagram', 'LinkedIn', 'Twitter', 'TikTok', 'YouTube'];
  
  const profiles: SocialMediaProfile[] = platforms.map(platform => {
    // Check if URL was provided for this platform
    const platformKey = platform.toLowerCase();
    let providedUrl = '';
    if (providedUrls) {
      if (platformKey === 'facebook') providedUrl = providedUrls.facebook || '';
      else if (platformKey === 'instagram') providedUrl = providedUrls.instagram || '';
      else if (platformKey === 'linkedin') providedUrl = providedUrls.linkedin || '';
      else if (platformKey === 'twitter') providedUrl = providedUrls.twitter || '';
      else if (platformKey === 'tiktok') providedUrl = providedUrls.tiktok || '';
      else if (platformKey === 'youtube') providedUrl = providedUrls.youtube || '';
    }
    const found = providedUrl.trim() !== '';
    const issues: string[] = [];
    
    if (found) {
      const profileComplete = Math.random() > 0.4;
      const postingFrequencies: Array<'Daily' | 'Weekly' | 'Monthly' | 'Rarely' | 'Never'> = 
        ['Daily', 'Weekly', 'Monthly', 'Rarely', 'Never'];
      const postingFrequency = postingFrequencies[Math.floor(Math.random() * postingFrequencies.length)];
      
      if (!profileComplete) {
        issues.push('Profile information incomplete');
      }
      if (postingFrequency === 'Rarely' || postingFrequency === 'Never') {
        issues.push('Infrequent posting activity');
      }
      if (Math.random() > 0.6) {
        issues.push('Low engagement rate');
      }
      if (Math.random() > 0.7) {
        issues.push('Missing bio or description');
      }
      if (Math.random() > 0.7) {
        issues.push('No profile picture or cover photo');
      }
      
      return {
        platform,
        url: providedUrl || `https://${platform.toLowerCase()}.com/${hostname.replace('www.', '')}`,
        found: true,
        profileComplete,
        postingFrequency,
        lastPostDate: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString(),
        followerCount: Math.floor(Math.random() * 50000) + 100,
        engagementRate: Math.random() * 10 + 0.5,
        issues
      };
    }
    
    return {
      platform,
      url: '',
      found: false,
      profileComplete: false,
      postingFrequency: 'Never',
      issues: ['Platform not found or not linked on website']
    };
  });
  
  const profilesFound = profiles.filter(p => p.found).length;
  const totalPlatforms = platforms.length;
  
  // Calculate score based on profiles found and their quality
  let score = (profilesFound / totalPlatforms) * 50; // 50 points for having profiles
  profiles.forEach(profile => {
    if (profile.found) {
      if (profile.profileComplete) score += 5;
      if (profile.postingFrequency === 'Daily') score += 5;
      else if (profile.postingFrequency === 'Weekly') score += 3;
      if ((profile.engagementRate || 0) > 5) score += 3;
    }
  });
  
  const recommendations: string[] = [];
  if (profilesFound < totalPlatforms) {
    recommendations.push(`Create profiles on ${totalPlatforms - profilesFound} missing platforms to expand reach`);
  }
  if (profiles.some(p => p.found && !p.profileComplete)) {
    recommendations.push('Complete all profile information including bio, contact details, and branding');
  }
  if (profiles.some(p => p.found && (p.postingFrequency === 'Rarely' || p.postingFrequency === 'Never'))) {
    recommendations.push('Increase posting frequency to at least weekly to maintain audience engagement');
  }
  if (profiles.some(p => p.found && (p.engagementRate || 0) < 3)) {
    recommendations.push('Improve engagement by responding to comments, using hashtags, and posting interactive content');
  }
  recommendations.push('Add social media links prominently on your website (header or footer)');
  recommendations.push('Maintain consistent branding across all social media platforms');
  
  return {
    profilesFound,
    totalPlatforms,
    overallScore: Math.min(Math.round(score), 100),
    profiles,
    recommendations
  };
}

function generateRecommendations(
  seo: SEOMetrics,
  performance: PerformanceMetrics,
  accessibility: AccessibilityMetrics,
  geo: GEOMetrics,
  socialMedia: SocialMediaAudit
): Recommendation[] {
  const recommendations: Recommendation[] = [];

  // SEO Recommendations
  if (!seo.hasH1) {
    recommendations.push({
      category: 'SEO',
      priority: 'Critical',
      title: 'Add H1 Heading',
      description: 'Your page is missing an H1 heading tag, which is crucial for SEO.',
      impact: 'Search engines use H1 tags to understand page content. Missing H1 can significantly reduce rankings.',
      implementation: 'Add a descriptive H1 tag at the top of your main content that includes your primary keyword.'
    });
  }

  if (seo.imageAltTags / seo.totalImages < 0.5) {
    recommendations.push({
      category: 'SEO',
      priority: 'High',
      title: 'Improve Image Alt Text Coverage',
      description: `Only ${Math.round((seo.imageAltTags / seo.totalImages) * 100)}% of images have alt text.`,
      impact: 'Alt text improves accessibility and helps search engines understand image content.',
      implementation: 'Add descriptive alt text to all images, focusing on keywords where appropriate.'
    });
  }

  if (!seo.structuredData) {
    recommendations.push({
      category: 'SEO',
      priority: 'High',
      title: 'Implement Structured Data',
      description: 'Your website lacks structured data markup.',
      impact: 'Structured data helps search engines display rich snippets, improving click-through rates by up to 30%.',
      implementation: 'Add JSON-LD schema markup for your business type, products, or services.'
    });
  }

  // Performance Recommendations
  if (performance.loadTime > 3) {
    recommendations.push({
      category: 'Performance',
      priority: 'Critical',
      title: 'Reduce Page Load Time',
      description: `Page loads in ${performance.loadTime.toFixed(2)}s, which is above the 3s threshold.`,
      impact: 'Every second of delay can reduce conversions by 7%. Users expect pages to load in under 3 seconds.',
      implementation: 'Optimise images, enable compression, use a CDN, and minify CSS/JS files.'
    });
  }

  if (performance.largestContentfulPaint > 2.5) {
    recommendations.push({
      category: 'Performance',
      priority: 'High',
      title: 'Improve Largest Contentful Paint (LCP)',
      description: `LCP is ${performance.largestContentfulPaint.toFixed(2)}s (target: <2.5s).`,
      impact: 'LCP is a Core Web Vital that affects SEO rankings and user experience.',
      implementation: 'Optimise your largest image or text block, use lazy loading, and improve server response times.'
    });
  }

  // Accessibility Recommendations
  if (accessibility.score < 80) {
    recommendations.push({
      category: 'Accessibility',
      priority: 'High',
      title: 'Improve Accessibility Score',
      description: `Accessibility score is ${accessibility.score}/100.`,
      impact: 'Poor accessibility excludes users with disabilities and may violate legal requirements.',
      implementation: 'Address critical and serious issues first: improve colour contrast, add ARIA labels, ensure keyboard navigation.'
    });
  }

  if (accessibility.issues.critical > 0) {
    recommendations.push({
      category: 'Accessibility',
      priority: 'Critical',
      title: 'Fix Critical Accessibility Issues',
      description: `Found ${accessibility.issues.critical} critical accessibility issues.`,
      impact: 'Critical issues prevent users with disabilities from accessing your content.',
      implementation: 'Review and fix issues related to screen reader compatibility, keyboard navigation, and form labels.'
    });
  }

  // GEO/AEO Recommendations
  if (geo.aiReadability < 70) {
    recommendations.push({
      category: 'GEO',
      priority: 'High',
      title: 'Optimise for AI Search Engines',
      description: `AI readability score is ${geo.aiReadability}/100.`,
      impact: 'With ChatGPT, Perplexity, and Google SGE, optimising for AI is crucial for future visibility.',
      implementation: 'Use clear headings, concise answers, FAQ sections, and structured data to help AI understand your content.'
    });
  }

  if (!geo.faqStructure) {
    recommendations.push({
      category: 'GEO',
      priority: 'Medium',
      title: 'Add FAQ Section',
      description: 'No FAQ structure detected on your website.',
      impact: 'FAQ sections help AI engines provide direct answers and improve featured snippet chances.',
      implementation: 'Create an FAQ page or section with common questions and concise answers using FAQ schema markup.'
    });
  }

  if (geo.schemaMarkup.length === 0) {
    recommendations.push({
      category: 'GEO',
      priority: 'High',
      title: 'Implement Schema Markup',
      description: 'No schema markup detected.',
      impact: 'Schema markup helps AI understand your business type, services, and content structure.',
      implementation: 'Add Organization, LocalBusiness, Product, or Service schema as appropriate for your business.'
    });
  }

  // Voice Search Recommendations
  recommendations.push({
    category: 'Voice',
    priority: 'Medium',
    title: 'Implement Voice Agent (Talking Website)',
    description: 'Enable voice interactions on your website for improved accessibility and engagement.',
    impact: 'Voice agents can answer customer questions 24/7, improve accessibility, and increase engagement by 40%.',
    implementation: 'Integrate an AI voice agent that can answer FAQs, guide users, and provide information via voice commands.'
  });

  // Google Business Recommendations
  recommendations.push({
    category: 'Google Business',
    priority: 'High',
    title: 'Optimise Google Business Profile',
    description: 'Ensure your Google Business Profile is fully optimised for local search.',
    impact: 'A well-optimised Google Business Profile can increase local visibility by 70% and drive more foot traffic.',
    implementation: 'Complete all profile sections, add high-quality photos, collect reviews, post regular updates, and ensure NAP consistency.'
  });

  // Social Media Recommendations
  if (socialMedia.profilesFound < socialMedia.totalPlatforms) {
    recommendations.push({
      category: 'Social Media',
      priority: 'High',
      title: 'Expand Social Media Presence',
      description: `Only ${socialMedia.profilesFound} out of ${socialMedia.totalPlatforms} major platforms detected.`,
      impact: 'Missing social media platforms means lost opportunities for customer engagement and brand awareness.',
      implementation: 'Create profiles on missing platforms (Facebook, Instagram, LinkedIn, Twitter, TikTok, YouTube) relevant to your industry.'
    });
  }

  const inactiveProfiles = socialMedia.profiles.filter(p => 
    p.found && (p.postingFrequency === 'Rarely' || p.postingFrequency === 'Never')
  );
  if (inactiveProfiles.length > 0) {
    recommendations.push({
      category: 'Social Media',
      priority: 'High',
      title: 'Increase Social Media Activity',
      description: `${inactiveProfiles.length} platform(s) have infrequent posting activity.`,
      impact: 'Inactive social media profiles damage credibility and reduce organic reach by up to 80%.',
      implementation: 'Develop a content calendar with at least weekly posts. Use scheduling tools to maintain consistency.'
    });
  }

  const incompleteProfiles = socialMedia.profiles.filter(p => p.found && !p.profileComplete);
  if (incompleteProfiles.length > 0) {
    recommendations.push({
      category: 'Social Media',
      priority: 'Medium',
      title: 'Complete Social Media Profiles',
      description: `${incompleteProfiles.length} platform(s) have incomplete profile information.`,
      impact: 'Incomplete profiles reduce trust and make it harder for customers to contact you.',
      implementation: 'Add complete bio, contact information, website links, and professional branding to all profiles.'
    });
  }

  if (socialMedia.overallScore < 70) {
    recommendations.push({
      category: 'Social Media',
      priority: 'Medium',
      title: 'Improve Social Media Engagement',
      description: 'Overall social media score indicates room for improvement.',
      impact: 'Strong social media presence can increase website traffic by 50% and improve brand recognition.',
      implementation: 'Respond to comments, use relevant hashtags, post engaging content, and maintain consistent branding across platforms.'
    });
  }

  return recommendations.sort((a, b) => {
    const priorityOrder = { Critical: 0, High: 1, Medium: 2, Low: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });
}

function calculateOverallScore(
  seo: SEOMetrics,
  performance: PerformanceMetrics,
  accessibility: AccessibilityMetrics,
  geo: GEOMetrics
): number {
  // SEO Score (25%)
  let seoScore = 0;
  seoScore += seo.hasH1 ? 15 : 0;
  seoScore += (seo.imageAltTags / seo.totalImages) * 20;
  seoScore += seo.httpsEnabled ? 15 : 0;
  seoScore += seo.mobileResponsive ? 15 : 0;
  seoScore += seo.structuredData ? 15 : 0;
  seoScore += seo.pageLoadTime < 3 ? 20 : seo.pageLoadTime < 5 ? 10 : 0;

  // Performance Score (25%)
  let perfScore = 0;
  perfScore += performance.loadTime < 2 ? 25 : performance.loadTime < 3 ? 15 : performance.loadTime < 4 ? 10 : 5;
  perfScore += performance.firstContentfulPaint < 1.8 ? 25 : performance.firstContentfulPaint < 3 ? 15 : 10;
  perfScore += performance.largestContentfulPaint < 2.5 ? 25 : performance.largestContentfulPaint < 4 ? 15 : 10;
  perfScore += performance.cumulativeLayoutShift < 0.1 ? 25 : performance.cumulativeLayoutShift < 0.25 ? 15 : 10;

  // Accessibility Score (25%)
  const accessScore = accessibility.score;

  // GEO Score (25%)
  const geoScore = (geo.aiReadability + geo.entityOptimisation + geo.contentDepth + geo.topicalAuthority) / 4;

  // Calculate weighted average
  const overallScore = (seoScore * 0.25 + perfScore * 0.25 + accessScore * 0.25 + geoScore * 0.25);
  
  return Math.round(overallScore);
}

export function getScoreColor(score: number): string {
  if (score >= 80) return 'text-green-500';
  if (score >= 60) return 'text-[#FFD700]'; // Gold
  if (score >= 40) return 'text-orange-500';
  return 'text-red-500';
}

export function getScoreLabel(score: number): string {
  if (score >= 80) return 'Excellent';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Needs Improvement';
  return 'Poor';
}
