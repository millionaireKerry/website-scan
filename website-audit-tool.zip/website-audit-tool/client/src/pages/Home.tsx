import { useState } from 'react';
import { toast } from 'sonner';
import AuditForm from '@/components/AuditForm';
import AuditReport from '@/components/AuditReport';
import { analyzeWebsite } from '@/lib/auditAnalysis';
import type { AuditFormData, AuditReport as AuditReportType } from '@/lib/types';
import { Sparkles } from 'lucide-react';

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [report, setReport] = useState<AuditReportType | null>(null);

  const handleSubmit = async (data: AuditFormData) => {
    setIsLoading(true);
    
    try {
      toast.info('Analysing your website...', {
        description: 'This may take a few moments'
      });

      const auditReport = await analyzeWebsite(data);
      setReport(auditReport);
      
      toast.success('Audit Complete!', {
        description: 'Your comprehensive website audit is ready'
      });

      // Scroll to top to show report
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      toast.error('Analysis Failed', {
        description: 'Please check the URL and try again'
      });
      console.error('Audit error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewAudit = () => {
    setReport(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-[#006D75] to-[#FFD700] flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  UK Business <span className="text-[#FFD700]">Automations</span>
                </h1>
                <p className="text-xs text-muted-foreground">AI-Powered Business Solutions</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        {!report ? (
          <div className="space-y-12">
            {/* Hero Section */}
            <div className="text-center max-w-3xl mx-auto space-y-6">
              <div className="inline-block">
                <div className="bg-[#006D75]/10 border border-[#006D75] text-[#006D75] px-4 py-2 rounded-full text-sm font-medium">
                  Free Website Audit Tool
                </div>
              </div>
              
              <h1 className="text-5xl md:text-6xl font-bold text-foreground">
                Discover Your Website's{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD700] to-[#006D75]">
                  Hidden Potential
                </span>
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Get a comprehensive, professional audit covering SEO, performance, accessibility, 
                AI optimisation, and competitor analysis—all in under 60 seconds.
              </p>

              <div className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-[#FFD700]"></div>
                  <span>SEO Analysis</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-[#006D75]"></div>
                  <span>Performance Metrics</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-[#FFD700]"></div>
                  <span>AI/GEO Optimisation</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-[#006D75]"></div>
                  <span>Competitor Insights</span>
                </div>
              </div>
            </div>

            {/* Form */}
            <AuditForm onSubmit={handleSubmit} isLoading={isLoading} />

            {/* Features */}
            <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
              <FeatureCard
                title="Comprehensive Analysis"
                description="Get detailed insights into SEO, performance, accessibility, and AI optimisation"
                gradient="from-[#006D75]/20 to-transparent"
              />
              <FeatureCard
                title="Competitor Benchmarking"
                description="See how you stack up against competitors with traffic and engagement data"
                gradient="from-[#FFD700]/20 to-transparent"
              />
              <FeatureCard
                title="Actionable Recommendations"
                description="Receive prioritised, step-by-step guidance to improve your website"
                gradient="from-[#006D75]/20 to-transparent"
              />
            </div>
          </div>
        ) : (
          <AuditReport report={report} onNewAudit={handleNewAudit} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-20">
        <div className="container py-8 text-center text-sm text-muted-foreground">
          <p>
            © 2026 UK Business Automations. All rights reserved.
          </p>
          <p className="mt-2">
            Helping UK businesses automate, optimise, and grow with AI-powered solutions.
          </p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ title, description, gradient }: { title: string; description: string; gradient: string }) {
  return (
    <div className={`p-6 rounded-lg bg-gradient-to-br ${gradient} border border-border`}>
      <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  );
}
