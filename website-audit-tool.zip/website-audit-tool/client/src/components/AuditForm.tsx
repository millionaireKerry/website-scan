import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Plus, X } from 'lucide-react';
import type { AuditFormData } from '@/lib/types';

interface AuditFormProps {
  onSubmit: (data: AuditFormData) => void;
  isLoading: boolean;
}

export default function AuditForm({ onSubmit, isLoading }: AuditFormProps) {
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [industry, setIndustry] = useState('');
  const [competitors, setCompetitors] = useState<string[]>(['', '']);
  const [socialMedia, setSocialMedia] = useState({
    facebook: '',
    instagram: '',
    linkedin: '',
    twitter: '',
    tiktok: '',
    youtube: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate
    if (!websiteUrl || !businessName || !industry) {
      return;
    }

    const validCompetitors = competitors.filter(c => c.trim() !== '');

    onSubmit({
      websiteUrl,
      businessName,
      industry,
      competitors: validCompetitors,
      socialMedia
    });
  };

  const addCompetitor = () => {
    setCompetitors([...competitors, '']);
  };

  const removeCompetitor = (index: number) => {
    setCompetitors(competitors.filter((_, i) => i !== index));
  };

  const updateCompetitor = (index: number, value: string) => {
    const updated = [...competitors];
    updated[index] = value;
    setCompetitors(updated);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto bg-card border-border">
      <CardHeader>
        <CardTitle className="text-3xl font-bold text-foreground">
          Free Website Audit
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Get a comprehensive analysis of your website's performance, SEO, accessibility, and AI optimisation
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="websiteUrl" className="text-foreground">
              Website URL *
            </Label>
            <Input
              id="websiteUrl"
              type="url"
              placeholder="https://example.com"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              required
              className="bg-input border-border text-foreground"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="businessName" className="text-foreground">
              Business Name *
            </Label>
            <Input
              id="businessName"
              type="text"
              placeholder="Your Business Name"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              required
              className="bg-input border-border text-foreground"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="industry" className="text-foreground">
              Industry *
            </Label>
            <Input
              id="industry"
              type="text"
              placeholder="e.g., Retail, Healthcare, Technology"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              required
              className="bg-input border-border text-foreground"
            />
          </div>

          <div className="space-y-3">
            <Label className="text-foreground">
              Social Media Links (Optional)
            </Label>
            <p className="text-sm text-muted-foreground">
              Add your social media profile URLs for comprehensive audit
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="facebook" className="text-sm text-muted-foreground">
                  Facebook
                </Label>
                <Input
                  id="facebook"
                  type="url"
                  placeholder="https://facebook.com/yourpage"
                  value={socialMedia.facebook}
                  onChange={(e) => setSocialMedia({...socialMedia, facebook: e.target.value})}
                  className="bg-input border-border text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="instagram" className="text-sm text-muted-foreground">
                  Instagram
                </Label>
                <Input
                  id="instagram"
                  type="url"
                  placeholder="https://instagram.com/yourprofile"
                  value={socialMedia.instagram}
                  onChange={(e) => setSocialMedia({...socialMedia, instagram: e.target.value})}
                  className="bg-input border-border text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="linkedin" className="text-sm text-muted-foreground">
                  LinkedIn
                </Label>
                <Input
                  id="linkedin"
                  type="url"
                  placeholder="https://linkedin.com/company/yourcompany"
                  value={socialMedia.linkedin}
                  onChange={(e) => setSocialMedia({...socialMedia, linkedin: e.target.value})}
                  className="bg-input border-border text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="twitter" className="text-sm text-muted-foreground">
                  Twitter/X
                </Label>
                <Input
                  id="twitter"
                  type="url"
                  placeholder="https://twitter.com/yourhandle"
                  value={socialMedia.twitter}
                  onChange={(e) => setSocialMedia({...socialMedia, twitter: e.target.value})}
                  className="bg-input border-border text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tiktok" className="text-sm text-muted-foreground">
                  TikTok
                </Label>
                <Input
                  id="tiktok"
                  type="url"
                  placeholder="https://tiktok.com/@yourhandle"
                  value={socialMedia.tiktok}
                  onChange={(e) => setSocialMedia({...socialMedia, tiktok: e.target.value})}
                  className="bg-input border-border text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="youtube" className="text-sm text-muted-foreground">
                  YouTube
                </Label>
                <Input
                  id="youtube"
                  type="url"
                  placeholder="https://youtube.com/@yourchannel"
                  value={socialMedia.youtube}
                  onChange={(e) => setSocialMedia({...socialMedia, youtube: e.target.value})}
                  className="bg-input border-border text-foreground"
                />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Label className="text-foreground">
              Competitor Websites (Optional)
            </Label>
            <p className="text-sm text-muted-foreground">
              Add up to 2 competitor websites for comparison
            </p>
            {competitors.map((competitor, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  type="url"
                  placeholder="https://competitor.com"
                  value={competitor}
                  onChange={(e) => updateCompetitor(index, e.target.value)}
                  className="bg-input border-border text-foreground"
                />
                {competitors.length > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => removeCompetitor(index)}
                    className="shrink-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            {competitors.length < 2 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addCompetitor}
                className="w-full border-dashed"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Competitor
              </Button>
            )}
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold text-lg py-6"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Analysing Website...
              </>
            ) : (
              'Generate Free Audit Report'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
