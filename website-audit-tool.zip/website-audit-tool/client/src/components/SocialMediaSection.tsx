import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, XCircle, AlertCircle, Facebook, Instagram, Linkedin, Twitter, Youtube } from 'lucide-react';
import type { SocialMediaAudit } from '@/lib/types';

interface SocialMediaSectionProps {
  socialMedia: SocialMediaAudit;
}

const platformIcons: Record<string, any> = {
  Facebook: Facebook,
  Instagram: Instagram,
  LinkedIn: Linkedin,
  Twitter: Twitter,
  TikTok: AlertCircle, // Using generic icon for TikTok
  YouTube: Youtube
};

const platformColors: Record<string, string> = {
  Facebook: '#1877F2',
  Instagram: '#E4405F',
  LinkedIn: '#0A66C2',
  Twitter: '#1DA1F2',
  TikTok: '#000000',
  YouTube: '#FF0000'
};

export default function SocialMediaSection({ socialMedia }: SocialMediaSectionProps) {
  const getFrequencyColor = (frequency: string) => {
    switch (frequency) {
      case 'Daily': return 'text-green-500';
      case 'Weekly': return 'text-[#FFD700]';
      case 'Monthly': return 'text-orange-500';
      case 'Rarely':
      case 'Never': return 'text-red-500';
      default: return 'text-gray-400';
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return `${Math.floor(diffDays / 30)} months ago`;
  };

  const formatNumber = (num?: number) => {
    if (!num) return '0';
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <Card className="p-8 bg-card/50 border-border/50 backdrop-blur-sm">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 rounded-lg bg-[#006D75]/10 border border-[#006D75]/20">
          <Instagram className="w-6 h-6 text-[#006D75]" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-foreground">Social Media Audit</h2>
          <p className="text-muted-foreground">Platform presence and engagement analysis</p>
        </div>
      </div>

      {/* Overall Score */}
      <div className="mb-8 p-6 rounded-lg bg-background/50 border border-border/50">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Overall Social Media Score</h3>
            <p className="text-sm text-muted-foreground">
              {socialMedia.profilesFound} of {socialMedia.totalPlatforms} platforms detected
            </p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold text-[#FFD700]">{socialMedia.overallScore}</div>
            <div className="text-sm text-muted-foreground">out of 100</div>
          </div>
        </div>
        <Progress value={socialMedia.overallScore} className="h-3" />
      </div>

      {/* Platform Details */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground mb-4">Platform Analysis</h3>
        
        {socialMedia.profiles.map((profile) => {
          const Icon = platformIcons[profile.platform];
          const color = platformColors[profile.platform];
          
          return (
            <Card 
              key={profile.platform} 
              className="p-6 bg-background/30 border-border/50 hover:border-[#006D75]/30 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4 flex-1">
                  <div 
                    className="p-3 rounded-lg"
                    style={{ backgroundColor: `${color}15`, border: `1px solid ${color}30` }}
                  >
                    <Icon className="w-6 h-6" style={{ color }} />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-lg font-semibold text-foreground">{profile.platform}</h4>
                      {profile.found ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                    
                    {profile.found ? (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">Profile Status</p>
                            <p className={`text-sm font-medium ${profile.profileComplete ? 'text-green-500' : 'text-orange-500'}`}>
                              {profile.profileComplete ? 'Complete' : 'Incomplete'}
                            </p>
                          </div>
                          
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">Posting Frequency</p>
                            <p className={`text-sm font-medium ${getFrequencyColor(profile.postingFrequency)}`}>
                              {profile.postingFrequency}
                            </p>
                          </div>
                          
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">Followers</p>
                            <p className="text-sm font-medium text-foreground">
                              {formatNumber(profile.followerCount)}
                            </p>
                          </div>
                          
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">Engagement Rate</p>
                            <p className="text-sm font-medium text-foreground">
                              {profile.engagementRate?.toFixed(1)}%
                            </p>
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Last Post</p>
                          <p className="text-sm text-foreground">{formatDate(profile.lastPostDate)}</p>
                        </div>
                        
                        {profile.issues.length > 0 && (
                          <div className="mt-3 p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
                            <p className="text-xs font-semibold text-orange-500 mb-2">Issues Found:</p>
                            <ul className="space-y-1">
                              {profile.issues.map((issue, idx) => (
                                <li key={idx} className="text-xs text-orange-500/90 flex items-start gap-2">
                                  <span className="text-orange-500 mt-0.5">•</span>
                                  <span>{issue}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {profile.url && (
                          <a 
                            href={profile.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-xs text-[#006D75] hover:text-[#FFD700] transition-colors inline-flex items-center gap-1"
                          >
                            View Profile →
                          </a>
                        )}
                      </div>
                    ) : (
                      <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                        <p className="text-sm text-red-500">
                          {profile.issues[0] || 'Platform not found or not linked on website'}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Recommendations */}
      {socialMedia.recommendations.length > 0 && (
        <div className="mt-8 p-6 rounded-lg bg-[#006D75]/10 border border-[#006D75]/20">
          <h3 className="text-lg font-semibold text-foreground mb-4">Social Media Recommendations</h3>
          <ul className="space-y-2">
            {socialMedia.recommendations.map((rec, idx) => (
              <li key={idx} className="text-sm text-foreground flex items-start gap-2">
                <span className="text-[#FFD700] mt-1">✓</span>
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Card>
  );
}
