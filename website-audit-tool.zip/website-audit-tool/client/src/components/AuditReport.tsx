import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  TrendingUp,
  Globe,
  Zap,
  Eye,
  Bot,
  Mic,
  MapPin,
  Download,
  ExternalLink
} from 'lucide-react';
import type { AuditReport as AuditReportType } from '@/lib/types';
import { getScoreColor, getScoreLabel } from '@/lib/auditAnalysis';
import SocialMediaSection from './SocialMediaSection';

interface AuditReportProps {
  report: AuditReportType;
  onNewAudit: () => void;
}

export default function AuditReport({ report, onNewAudit }: AuditReportProps) {
  const COLORS = ['#006D75', '#008B95', '#FFD700', '#FFE44D'];

  const overallData = [
    { name: 'SEO', score: calculateSEOScore(report.seo) },
    { name: 'Performance', score: calculatePerformanceScore(report.performance) },
    { name: 'Accessibility', score: report.accessibility.score },
    { name: 'AI/GEO', score: calculateGEOScore(report.geo) }
  ];

  const competitorTrafficData = report.competitors.map(comp => ({
    name: comp.name,
    visits: comp.monthlyVisits / 1000
  }));

  const trafficSourcesData = report.competitors.length > 0 ? [
    { name: 'Direct', value: report.competitors[0].trafficSources.direct },
    { name: 'Search', value: report.competitors[0].trafficSources.search },
    { name: 'Social', value: report.competitors[0].trafficSources.social },
    { name: 'Referral', value: report.competitors[0].trafficSources.referral }
  ] : [];

  const handleDownload = () => {
    // In a real implementation, this would generate a PDF
    alert('PDF download functionality would be implemented here');
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-8 pb-16">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Website Audit Report
          </h1>
          <p className="text-muted-foreground">
            {report.businessName} • {new Date(report.generatedAt).toLocaleDateString('en-GB')}
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={handleDownload}>
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
          <Button variant="outline" onClick={onNewAudit}>
            New Audit
          </Button>
        </div>
      </div>

      {/* Overall Score */}
      <Card className="bg-gradient-to-br from-card to-secondary border-border">
        <CardHeader>
          <CardTitle className="text-2xl">Overall Score</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center">
            <div className="text-center">
              <div className={`text-7xl font-bold ${getScoreColor(report.overallScore)}`}>
                {report.overallScore}
              </div>
              <div className="text-2xl text-muted-foreground mt-2">
                {getScoreLabel(report.overallScore)}
              </div>
            </div>
          </div>
          <div className="mt-8">
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={overallData}>
                <PolarGrid stroke="#333" />
                <PolarAngleAxis dataKey="name" stroke="#fff" />
                <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#666" />
                <Radar
                  name="Your Website"
                  dataKey="score"
                  stroke="#FFD700"
                  fill="#FFD700"
                  fillOpacity={0.3}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          icon={<Globe className="h-5 w-5" />}
          title="SEO Score"
          score={calculateSEOScore(report.seo)}
          color="text-[#006D75]"
        />
        <MetricCard
          icon={<Zap className="h-5 w-5" />}
          title="Performance"
          score={calculatePerformanceScore(report.performance)}
          color="text-[#FFD700]"
        />
        <MetricCard
          icon={<Eye className="h-5 w-5" />}
          title="Accessibility"
          score={report.accessibility.score}
          color="text-[#008B95]"
        />
        <MetricCard
          icon={<Bot className="h-5 w-5" />}
          title="AI/GEO"
          score={calculateGEOScore(report.geo)}
          color="text-[#FFE44D]"
        />
      </div>

      {/* SEO Details */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-[#006D75]" />
            SEO Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <DetailItem
              label="H1 Tag Present"
              value={report.seo.hasH1}
              type="boolean"
            />
            <DetailItem
              label="HTTPS Enabled"
              value={report.seo.httpsEnabled}
              type="boolean"
            />
            <DetailItem
              label="Mobile Responsive"
              value={report.seo.mobileResponsive}
              type="boolean"
            />
            <DetailItem
              label="Structured Data"
              value={report.seo.structuredData}
              type="boolean"
            />
            <DetailItem
              label="Image Alt Tags"
              value={`${report.seo.imageAltTags}/${report.seo.totalImages}`}
              type="text"
            />
            <DetailItem
              label="Internal Links"
              value={report.seo.internalLinks.toString()}
              type="text"
            />
            <DetailItem
              label="Page Load Time"
              value={`${report.seo.pageLoadTime.toFixed(2)}s`}
              type="text"
            />
            <DetailItem
              label="Meta Description"
              value={report.seo.metaDescription.length > 0}
              type="boolean"
            />
          </div>
        </CardContent>
      </Card>

      {/* Performance Details */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-[#FFD700]" />
            Performance Metrics
          </CardTitle>
          <CardDescription>Core Web Vitals and loading performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <PerformanceMetric
              label="First Contentful Paint (FCP)"
              value={report.performance.firstContentfulPaint}
              threshold={1.8}
              unit="s"
            />
            <PerformanceMetric
              label="Largest Contentful Paint (LCP)"
              value={report.performance.largestContentfulPaint}
              threshold={2.5}
              unit="s"
            />
            <PerformanceMetric
              label="Cumulative Layout Shift (CLS)"
              value={report.performance.cumulativeLayoutShift}
              threshold={0.1}
              unit=""
              inverse
            />
            <PerformanceMetric
              label="Time to Interactive (TTI)"
              value={report.performance.timeToInteractive}
              threshold={3.8}
              unit="s"
            />
            <PerformanceMetric
              label="Total Blocking Time (TBT)"
              value={report.performance.totalBlockingTime}
              threshold={300}
              unit="ms"
            />
          </div>
        </CardContent>
      </Card>

      {/* GEO/AEO Section */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-[#008B95]" />
            AI Search Engine Optimisation (GEO/AEO)
          </CardTitle>
          <CardDescription>
            Optimisation for ChatGPT, Perplexity, Google SGE, and other AI search engines
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">AI Readability</span>
                <span className="text-sm text-muted-foreground">{report.geo.aiReadability}%</span>
              </div>
              <Progress value={report.geo.aiReadability} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Entity Optimisation</span>
                <span className="text-sm text-muted-foreground">{report.geo.entityOptimisation}%</span>
              </div>
              <Progress value={report.geo.entityOptimisation} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Content Depth</span>
                <span className="text-sm text-muted-foreground">{report.geo.contentDepth}%</span>
              </div>
              <Progress value={report.geo.contentDepth} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Topical Authority</span>
                <span className="text-sm text-muted-foreground">{report.geo.topicalAuthority}%</span>
              </div>
              <Progress value={report.geo.topicalAuthority} className="h-2" />
            </div>
          </div>

          <Separator />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <DetailItem
              label="Structured Data Present"
              value={report.geo.structuredDataPresent}
              type="boolean"
            />
            <DetailItem
              label="FAQ Structure"
              value={report.geo.faqStructure}
              type="boolean"
            />
            <div className="col-span-2">
              <p className="text-sm font-medium mb-2">Schema Markup Detected</p>
              <div className="flex flex-wrap gap-2">
                {report.geo.schemaMarkup.length > 0 ? (
                  report.geo.schemaMarkup.map((schema, i) => (
                    <Badge key={i} variant="secondary">
                      {schema}
                    </Badge>
                  ))
                ) : (
                  <span className="text-sm text-muted-foreground">No schema markup detected</span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Voice Agent Recommendation */}
      <Card className="bg-gradient-to-r from-[#006D75]/20 to-[#FFD700]/20 border-[#006D75]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5 text-[#FFD700]" />
            Voice Agent Integration
          </CardTitle>
          <CardDescription className="text-foreground/80">
            Transform your website into a talking website with AI voice agents
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-foreground/90">
            Voice agents can revolutionise customer engagement by providing instant, conversational responses to visitor queries. 
            Benefits include:
          </p>
          <ul className="space-y-2 text-foreground/90">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700] mt-0.5 shrink-0" />
              <span>24/7 customer support without human intervention</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700] mt-0.5 shrink-0" />
              <span>Improved accessibility for visually impaired users</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700] mt-0.5 shrink-0" />
              <span>Increased engagement and conversion rates by up to 40%</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700] mt-0.5 shrink-0" />
              <span>Natural language interactions that feel human</span>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Google Business Profile */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-[#006D75]" />
            Google Business Profile Optimisation
          </CardTitle>
          <CardDescription>
            Essential for local SEO and customer discovery
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-foreground/90">
            Your Google Business Profile is often the first impression potential customers have of your business. 
            Optimisation checklist:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700]" />
              <span className="text-sm">Complete all profile sections</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700]" />
              <span className="text-sm">Add high-quality photos (10+)</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700]" />
              <span className="text-sm">Collect and respond to reviews</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700]" />
              <span className="text-sm">Post regular updates</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700]" />
              <span className="text-sm">Ensure NAP consistency</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-[#FFD700]" />
              <span className="text-sm">Add business attributes</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Social Media Audit */}
      <SocialMediaSection socialMedia={report.socialMedia} />

      {/* Competitor Analysis */}
      {report.competitors.length > 0 && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-[#006D75]" />
              Competitor Analysis
            </CardTitle>
            <CardDescription>
              Compare your website's performance against competitors
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="text-sm font-medium mb-4">Monthly Traffic Comparison - Your Site vs Competitors</h4>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={competitorTrafficData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="name" stroke="#999" />
                  <YAxis stroke="#999" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                    labelStyle={{ color: '#fff' }}
                  />
                  <Bar dataKey="visits" fill="#006D75" />
                </BarChart>
              </ResponsiveContainer>
              <p className="text-xs text-muted-foreground mt-2">* Traffic in thousands (K)</p>
            </div>

            {trafficSourcesData.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-4">Traffic Sources Distribution</h4>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={trafficSourcesData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {trafficSourcesData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {report.competitors.map((comp, i) => (
                <Card key={i} className="bg-secondary border-border">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center justify-between">
                      {comp.name}
                      <a
                        href={comp.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#FFD700] hover:text-[#FFE44D]"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Monthly Visits:</span>
                      <span className="font-medium">{(comp.monthlyVisits / 1000).toFixed(1)}K</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Bounce Rate:</span>
                      <span className="font-medium">{comp.bounceRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Avg. Duration:</span>
                      <span className="font-medium">{Math.floor(comp.avgVisitDuration / 60)}m {comp.avgVisitDuration % 60}s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Pages/Visit:</span>
                      <span className="font-medium">{comp.pagesPerVisit.toFixed(1)}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recommendations */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Actionable Recommendations</CardTitle>
          <CardDescription>
            Prioritised improvements to boost your website's performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {report.recommendations.map((rec, i) => (
              <RecommendationCard key={i} recommendation={rec} />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* CTA */}
      <Card className="bg-gradient-to-r from-[#006D75] to-[#004D54] border-[#FFD700]">
        <CardContent className="py-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Transform Your Digital Presence?
            </h2>
            <p className="text-white/90 text-lg mb-2 max-w-2xl mx-auto">
              UK Business Automations specialises in implementing AI-powered solutions that drive real results.
            </p>
            <p className="text-white/80 text-base max-w-2xl mx-auto">
              Get your personalised action plan and quote. Most clients see results within 6-9 months.
            </p>
          </div>
          
          {/* High Level Form Integration Placeholder */}
          <div className="max-w-xl mx-auto bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
            <h3 className="text-xl font-semibold text-white mb-6 text-center">
              Get Your Free Consultation
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-white/90 mb-2">Full Name *</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 rounded-lg bg-white/90 text-black border-0 focus:ring-2 focus:ring-[#FFD700]"
                  placeholder="John Smith"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-white/90 mb-2">Email Address *</label>
                <input 
                  type="email" 
                  className="w-full px-4 py-3 rounded-lg bg-white/90 text-black border-0 focus:ring-2 focus:ring-[#FFD700]"
                  placeholder="john@company.co.uk"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-white/90 mb-2">Phone Number *</label>
                <input 
                  type="tel" 
                  className="w-full px-4 py-3 rounded-lg bg-white/90 text-black border-0 focus:ring-2 focus:ring-[#FFD700]"
                  placeholder="07XXX XXXXXX"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-white/90 mb-2">Biggest Challenge</label>
                <textarea 
                  className="w-full px-4 py-3 rounded-lg bg-white/90 text-black border-0 focus:ring-2 focus:ring-[#FFD700] h-24"
                  placeholder="What's your biggest digital marketing challenge?"
                />
              </div>
              
              <Button 
                size="lg" 
                className="w-full bg-[#FFD700] text-black hover:bg-[#FFE44D] font-bold text-lg py-6"
                onClick={() => {
                  // TODO: Replace with actual High Level form submission
                  alert('High Level Form Integration: This will submit to your High Level CRM. Replace this alert with actual form submission logic.');
                }}
              >
                Get My Free Action Plan & Quote
              </Button>
              
              <p className="text-xs text-white/60 text-center mt-4">
                By submitting this form, you agree to receive communications from UK Business Automations. 
                We respect your privacy and will never share your information.
              </p>
            </div>
          </div>
          
          <div className="mt-8 text-center">
            <a 
              href="https://ukbusinessautomations.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-[#FFD700] hover:text-[#FFE44D] text-sm underline"
            >
              Visit ukbusinessautomations.com →
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper Components
function MetricCard({ icon, title, score, color }: { icon: React.ReactNode; title: string; score: number; color: string }) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between mb-2">
          <div className={color}>{icon}</div>
          <span className={`text-3xl font-bold ${getScoreColor(score)}`}>
            {score}
          </span>
        </div>
        <p className="text-sm text-muted-foreground">{title}</p>
        <Progress value={score} className="mt-2 h-2" />
      </CardContent>
    </Card>
  );
}

function DetailItem({ label, value, type }: { label: string; value: any; type: 'boolean' | 'text' }) {
  return (
    <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
      <span className="text-sm text-muted-foreground">{label}</span>
      {type === 'boolean' ? (
        value ? (
          <CheckCircle2 className="h-5 w-5 text-green-500" />
        ) : (
          <XCircle className="h-5 w-5 text-red-500" />
        )
      ) : (
        <span className="text-sm font-medium">{value}</span>
      )}
    </div>
  );
}

function PerformanceMetric({
  label,
  value,
  threshold,
  unit,
  inverse = false
}: {
  label: string;
  value: number;
  threshold: number;
  unit: string;
  inverse?: boolean;
}) {
  const isGood = inverse ? value < threshold : value > threshold;
  const percentage = inverse
    ? Math.min((threshold / value) * 100, 100)
    : Math.min((value / threshold) * 100, 100);

  return (
    <div>
      <div className="flex justify-between mb-2">
        <span className="text-sm font-medium">{label}</span>
        <span className={`text-sm font-medium ${isGood ? 'text-green-500' : 'text-red-500'}`}>
          {value.toFixed(2)}{unit}
        </span>
      </div>
      <Progress value={percentage} className="h-2" />
      <p className="text-xs text-muted-foreground mt-1">
        Target: {inverse ? '<' : '>'} {threshold}{unit}
      </p>
    </div>
  );
}

function RecommendationCard({ recommendation }: { recommendation: any }) {
  const priorityColors = {
    Critical: 'bg-red-500/20 text-red-500 border-red-500',
    High: 'bg-orange-500/20 text-orange-500 border-orange-500',
    Medium: 'bg-[#FFD700]/20 text-[#FFD700] border-[#FFD700]',
    Low: 'bg-blue-500/20 text-blue-500 border-blue-500'
  };

  const categoryIcons = {
    SEO: <Globe className="h-4 w-4" />,
    Performance: <Zap className="h-4 w-4" />,
    Accessibility: <Eye className="h-4 w-4" />,
    GEO: <Bot className="h-4 w-4" />,
    Voice: <Mic className="h-4 w-4" />,
    'Google Business': <MapPin className="h-4 w-4" />
  };

  return (
    <Card className="bg-secondary border-border">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            {categoryIcons[recommendation.category as keyof typeof categoryIcons]}
            <CardTitle className="text-lg">{recommendation.title}</CardTitle>
          </div>
          <Badge className={priorityColors[recommendation.priority as keyof typeof priorityColors]}>
            {recommendation.priority}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-foreground/90">{recommendation.description}</p>
        <div className="space-y-2">
          <div className="flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-[#FFD700] mt-0.5 shrink-0" />
            <div>
              <p className="text-xs font-medium text-muted-foreground">Impact</p>
              <p className="text-sm">{recommendation.impact}</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-[#006D75] mt-0.5 shrink-0" />
            <div>
              <p className="text-xs font-medium text-muted-foreground">Implementation</p>
              <p className="text-sm">{recommendation.implementation}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Score calculation helpers
function calculateSEOScore(seo: any): number {
  let score = 0;
  score += seo.hasH1 ? 20 : 0;
  score += (seo.imageAltTags / seo.totalImages) * 20;
  score += seo.httpsEnabled ? 20 : 0;
  score += seo.mobileResponsive ? 20 : 0;
  score += seo.structuredData ? 20 : 0;
  return Math.round(score);
}

function calculatePerformanceScore(perf: any): number {
  let score = 0;
  score += perf.loadTime < 2 ? 25 : perf.loadTime < 3 ? 15 : 10;
  score += perf.firstContentfulPaint < 1.8 ? 25 : perf.firstContentfulPaint < 3 ? 15 : 10;
  score += perf.largestContentfulPaint < 2.5 ? 25 : perf.largestContentfulPaint < 4 ? 15 : 10;
  score += perf.cumulativeLayoutShift < 0.1 ? 25 : perf.cumulativeLayoutShift < 0.25 ? 15 : 10;
  return Math.round(score);
}

function calculateGEOScore(geo: any): number {
  return Math.round((geo.aiReadability + geo.entityOptimisation + geo.contentDepth + geo.topicalAuthority) / 4);
}
